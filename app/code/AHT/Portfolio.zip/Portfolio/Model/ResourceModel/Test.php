<?php 

namespace AHT\Portfolio\Model\ResourceModel;

use Magento\Framework\Model\AbstractModel;
use Magento\Store\Model\Store;


class Test extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb {

    public function __construct(
        \Magento\Framework\Model\ResourceModel\Db\Context $context
    )
    {
        parent::__construct($context);
        
    }
    public function _construct()
    {
        return $this->_init("portfolio","id");
        
    }
    public function load(AbstractModel $object, $value, $field = null)
    {
        if (!is_numeric($value) && is_null($field)) {
            $field = 'id';
        }
        return parent::load($object, $value, $field);
    }

    protected function _afterLoad(AbstractModel $object)
    {
        if ($object->getId()) {
            $stores = $this->lookupStoreIds($object->getId());
            $object->setData('store_id', $stores);
        }
        return parent::_afterLoad($object);
    }

    protected function _getLoadSelect($field, $value, $object)
    {
        $select = parent::_getLoadSelect($field, $value, $object);
        if ($object->getStoreId()) {
            $storeIds = [Store::DEFAULT_STORE_ID, (int)$object->getStoreId()];
            $select->join(
                ['portfolio_store' => $this->getTable('portfolio_store')],
                $this->getMainTable() . '.id = portfolio_store.id',
                []
            )->where(
                'status = ?',
                1
            )->where(
                'portfolio_store.store_id IN (?)',
                $storeIds
            )->order(
                'portfolio_store.store_id DESC'
            )->limit(
                1
            );
        }
        return $select;
    }


    protected function _afterSave(\Magento\Framework\Model\AbstractModel $object)
    {   
        $oldStores = $this->lookupStoreIds($object->getId());
        $newStores = (array)$object->getStores();
        if (empty($newStores)) {
            $newStores = (array)$object->getStoreId();
        }
        $table = $this->getTable('portfolio_store');
        $insert = array_diff($newStores, $oldStores);
        $delete = array_diff($oldStores, $newStores);
        if ($delete) {
            $where = ['id = ?' => (int)$object->getId(), 'store_id IN (?)' => $delete];
            $this->getConnection()->delete($table, $where);
        }
        if ($insert) {
            $data = [];
            foreach ($insert as $storeId) {
                $data[] = ['id' => (int)$object->getId(), 'store_id' => (int)$storeId];
            }
            $this->getConnection()->insertMultiple($table, $data);
        }

        if(isset($_FILES['filename']['name']) && $_FILES['filename']['name'] != '') {
			try {
				$uploader = $this->_fileUploaderFactory->create(['fileId' => 'filename']);
				$uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png']);
				$uploader->setAllowRenameFiles(true);
				$uploader->setFilesDispersion(true);
				
			} catch (\Exception $e) {
				return $this;
			}
			$path = $this->_filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath('portfolio/');
			$uploader->save($path);
			$fileName = $uploader->getUploadedFileName();
			if ($fileName) {
				$object->setData('filename', $fileName);
				$object->save();
			}
			return $this;
        }
        return parent::_afterSave($object);
    }
    public function lookupStoreIds($postId)
    {
        $connection = $this->getConnection();
        $select = $connection->select()->from(
            $this->getTable('portfolio_store'),
            'store_id'
        )->where(
            'id = ?',
            (int)$postId
        );
        return $connection->fetchCol($select);
    }


}