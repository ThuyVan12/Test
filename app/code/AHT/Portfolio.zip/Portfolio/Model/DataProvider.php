<?php 

namespace AHT\Portfolio\Model;

use AHT\Portfolio\Model\ResourceModel\Test\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\TestFramework\ObjectManager;
use Magento\Ui\DataProvider\Modifier\PoolInterface;
use AHT\Portfolio\Model\FileInfo;
use Magento\Framework\Filesystem;

class DataProvider extends \Magento\Ui\DataProvider\ModifierPoolDataProvider {

    protected $dataPersistor;
     
    protected $collection;

    private $fileInfo;
   
    protected $loadedData;

    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $portfolioCollectionFactory,
        DataPersistorInterface $dataPersistor,
        array $meta = [],
        array $data = [],
        PoolInterface $pool = null
    )
    {
        $this->collection = $portfolioCollectionFactory->create();
        $this->dataPersistor = $dataPersistor;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data, $pool);
    }
    public function getData()
     {
         if(isset($this->loadedData)) {
             return $this->loadedData;
         }
         $items = $this->collection->getItems();
         foreach ($items as $block) {
             $block = $this->convertValues($block);
             $this->loadedData[$block->getId()] = $block->getdata();
         }

         $data = $this->dataPersistor->get('portfolio');
         if (!empty($data)) {
             $portfolio = $this->collection->getNewEmptyItem();
             $portfolio->setData($data);
             $this->loadedData[$portfolio->getId()] = $portfolio->getData();
             $this->dataPersistor->clear('portfolio');
         }
         return $this->loadedData;

     }

     function convertValues($banner)
     {
        $fileName = $banner->getImage();
        $image = [];
        if ($this->getFileInfo()->isExist($fileName)) {
            $stat = $this->getFileInfo()->getStat($fileName);
            $mime = $this->getFileInfo()->getMimeType($fileName);
            $image[0]['name'] = $fileName;
            $image[0]['url'] = $banner->getImageUrl();
            $image[0]['size'] = isset($stat) ? $stat['size'] : 0;
            $image[0]['type'] = $mime;
        }
        $banner->setImage($image);

        return $banner;
     }

     private function getFileInfo()
     {
         if ($this->fileInfo === null) {
             $this->fileInfo = ObjectManager::getInstance()->get(FileInfo::class);
         }
         return $this->fileInfo;
     }
}