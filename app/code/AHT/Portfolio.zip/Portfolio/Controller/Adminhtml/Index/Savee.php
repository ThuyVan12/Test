<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace AHT\Portfolio\Controller\Adminhtml\Index;

use AHT\Portfolio\Controller\Adminhtml\Index\abAction;
use AHT\Portfolio\Model\ImageUploader;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Backend\App\Action\Context;
use AHT\Portfolio\Model\ResourceModel\Test as Resource;
use AHT\Portfolio\Model\TestFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Registry;

/**
 * Save CMS block action.
 */
class Save extends abAction implements HttpPostActionInterface
{
    protected $resource;
    
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        DataPersistorInterface $dataPersistor,
        TestFactory $questionFactory,
        Resource $resource,
        ImageUploader $imageUploader,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resources = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->dataPersistor = $dataPersistor;
        $this->questionFactory = $questionFactory;
        $this->resource = $resource;
        $this->imageUploader = $imageUploader;
        parent::__construct($context, $registry, $resources, $resourceCollection, $data);
    }
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        if($data) {
            if(empty($data['id'])) {
                $data['id'] = null;
            }
        }
        $imageName = '';
        if(!empty($data['image'])) {
            $imageName = $data['image'][0]['name'];
            $data['image'] = $imageName;
        }
        $model = $this->questionFactory->create();

        $id = $this->getRequest()->getParam('id');
        if($id) {
            $model->load($id);
            return $resultRedirect->setPath('*/*/');
        }
        $model->setData($data);
      
        $this->resource->save($model);
    }

}